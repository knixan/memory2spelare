const imagePaths = [
  "content/image/emilia.jpg",
  "content/image/esmeralda.jpg",
  "content/image/kiaojossan.jpg",
  "content/image/kjell.jpg",
  "content/image/brormefru.jpg",
  "content/image/tyson.jpg",
  "content/image/tyson2.jpg",
  "content/image/jonny.jpg",
];

let cards = [...imagePaths, ...imagePaths];
let firstCard = null;
let lockBoard = true;
let timerInterval;
let timeLeft = 60;
let currentPlayer = 1;
let scores = [0, 0];
let totalMatches = 0;

const gameBoard = document.querySelector(".game-board");
const timerDisplay = document.getElementById("timer");
const messageDisplay = document.getElementById("message");
const turnDisplay = document.getElementById("turn");
const score1Display = document.getElementById("score1");
const score2Display = document.getElementById("score2");
const startBtn = document.getElementById("startBtn");
const resetBtn = document.getElementById("resetBtn");
const highscoreDisplay = document.getElementById("highscore");

startBtn.addEventListener("click", () => {
  startBtn.disabled = true;
  resetBtn.disabled = false;
  timerDisplay.style.display = "block";
  lockBoard = true;
  initGame(true);
});

resetBtn.addEventListener("click", () => location.reload());

function startTimer() {
  timerDisplay.textContent = `Tid kvar: ${timeLeft} sekunder`;
  timerInterval = setInterval(() => {
    timeLeft--;
    timerDisplay.textContent = `Tid kvar: ${timeLeft} sekunder`;
    if (timeLeft <= 0) {
      clearInterval(timerInterval);
      endGame("Tiden är slut!");
    }
  }, 1000);
}

function endGame(message) {
  lockBoard = true;
  const winner =
    scores[0] > scores[1]
      ? "Spelare 1"
      : scores[1] > scores[0]
      ? "Spelare 2"
      : "Oavgjort";

  messageDisplay.textContent = `${message} Vinnare: ${winner}`;
  saveHighscore(winner);
  showHighscore();
}

function updateScores() {
  score1Display.textContent = scores[0];
  score2Display.textContent = scores[1];
}

function switchPlayer() {
  currentPlayer = currentPlayer === 1 ? 2 : 1;
  turnDisplay.textContent = `Spelare: ${currentPlayer}`;
}

function initGame(showAll = false) {
  cards.sort(() => 0.5 - Math.random());
  gameBoard.innerHTML = "";

  const allCards = [];

  cards.forEach((imgPath) => {
    const card = document.createElement("div");
    card.classList.add("card");
    card.dataset.image = imgPath;

    const cardInner = document.createElement("div");
    cardInner.classList.add("card-inner");

    const front = document.createElement("div");
    front.classList.add("card-front");
    const img = document.createElement("img");
    img.src = imgPath;
    front.appendChild(img);

    const back = document.createElement("div");
    back.classList.add("card-back");

    cardInner.appendChild(back);
    cardInner.appendChild(front);
    card.appendChild(cardInner);

    if (showAll) card.classList.add("flipped");

    card.addEventListener("click", () => {
      if (
        lockBoard ||
        card.classList.contains("flipped") ||
        card.classList.contains("matched")
      )
        return;

      card.classList.add("flipped");

      if (!firstCard) {
        firstCard = card;
      } else {
        const secondCard = card;
        if (firstCard.dataset.image === secondCard.dataset.image) {
          firstCard.classList.add("matched");
          secondCard.classList.add("matched");
          scores[currentPlayer - 1]++;
          totalMatches++;
          updateScores();
          firstCard = null;

          if (document.querySelectorAll(".matched").length === cards.length) {
            clearInterval(timerInterval);
            endGame("Spelet över!");
          }
        } else {
          lockBoard = true;
          setTimeout(() => {
            firstCard.classList.remove("flipped");
            secondCard.classList.remove("flipped");
            firstCard = null;
            switchPlayer();
            lockBoard = false;
          }, 1000);
        }
      }
    });

    gameBoard.appendChild(card);
    allCards.push(card);
  });

  if (showAll) {
    setTimeout(() => {
      allCards.forEach((card) => card.classList.remove("flipped"));
      lockBoard = false;
      startTimer();
    }, 2000);
  } else {
    lockBoard = false;
  }
}

function saveHighscore(winner) {
  const history = JSON.parse(localStorage.getItem("memoryHighscores")) || [];
  history.push({
    winner,
    score1: scores[0],
    score2: scores[1],
    totalMatches,
    date: new Date().toLocaleString(),
  });
  localStorage.setItem("memoryHighscores", JSON.stringify(history));
}

function showHighscore() {
  const history = JSON.parse(localStorage.getItem("memoryHighscores")) || [];
  if (history.length === 0) return;

  const latest = history[history.length - 1];
  highscoreDisplay.innerHTML = `
        <hr>
        <strong>Senaste resultat:</strong><br>
        Vinnare: ${latest.winner} <br>
        Spelare 1: ${latest.score1} poäng<br>
        Spelare 2: ${latest.score2} poäng<br>
        Matcher hittade: ${latest.totalMatches}<br>
        Tid: ${latest.date}
      `;
}

showHighscore();
